package com.example.day6.day6.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Enabled {
  @Test
  public void Test() throws InterruptedException {
	  WebDriverManager.firefoxdriver().setup();
	  WebDriver driver = new FirefoxDriver();
	  Thread.sleep(5000);
	  driver.get("http://google.com/");
	  driver.navigate().to("https://www.godaddy.com/en-in/domains");
  }
 
  
}
