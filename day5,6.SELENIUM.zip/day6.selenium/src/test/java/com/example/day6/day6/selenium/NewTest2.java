package com.example.day6.day6.selenium;

import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest2 {
	static int a=1;static int b=2;
  @Test(priority=1)
  
  static public void add() {
	  int aans=a+b;
	  Assert.assertEquals(3, aans);
  }
  @Test(priority=2)
  static public void sub() {
	  int sans=a-b;
	  Assert.assertEquals(-1, sans);
  }
  @Test(priority=3)
  static public void mul() {
	  int mans=a*b;
	  Assert.assertEquals(2, mans);
  }
  @Test(priority=4)
  static public void div() {
	  int dans=a/b;
	  Assert.assertEquals(0, dans);

  }
//  public static void main(String[] args) {
//	  void c1=add(a,b);
//	  void c2=sub(a,b);
//	  void c3=mul(a,b);
//	  void c4=div(a,b);
//	  Assert.assertEquals(3, c1);
//	  Assert.assertEquals(-1, c2);
//	  Assert.assertEquals(2, c3);
//	  Assert.assertEquals(0, c4);
//  }
}
